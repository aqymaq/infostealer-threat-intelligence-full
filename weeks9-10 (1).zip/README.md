# Infostealer Threat Intelligence

Group project for the 2026–2027 CTI practice. Scope: information-stealing malware as a **class of threats**; no specific family is the project title or assumed source of all evidence.

## Research question

How do infostealers obtain and transfer sensitive data, which public evidence is reliable, and how can defenders detect the relevant behaviors?

| Week | Deliverable | State |
|---|---|---|
| 1 | [Glossary and threat/source classification](week01/report.md) | Desk research completed; group review required |
| 2 | [Purpose-driven OSINT collection plan](week02/report.md) | Public-source research and VT/Shodan lookups completed; Maltego graph pending |
| 3 | [Filtering, normalization and MISP plan](week03/report.md) | MISP deployment/import pending |
| 8 | [Adversary emulation plan (CALDERA / ATT&CK)](week8/report.md) | Plan documented; execution deferred to Weeks 9–10 |
| 9 | [Atomic Red Team — benign tests + SIEM detection](week9/report.md) | Test selection and detection logic documented; closes W8 persistence gap |
| 10 | [Learning APT techniques — APT41 TTPs mapped to ATT&CK](week10/report.md) | CTI analysis of public reporting (Mandiant APT1, CrowdStrike GTR) |

Week 1 [defense outline](week01/defense.md) is for a 7–8 minute group presentation. Public references are evidence of general behaviors; they are not observations on our university network. The group will choose one or more **documented public examples for individual evidence records in Week 2** without renaming the overarching topic.

**Group members:** Miras Sailauuly, Asilbek Turgunov, Zhanibek Zhurgen.  
**Teacher / section:** Noyan Tendikov

## Publish on GitHub

This folder already has an initial local commit. Unzip it, add the folder as a local repository in GitHub Desktop, and use **Publish repository**. Make separate commits when your group collects Week 2 evidence and completes Week 3 MISP work. Do not upload malware binaries, credentials, private browser data or API keys.

## Use of AI

AI tools were used as supporting tools during this project. They assisted with:

- organizing and structuring the report;
- improving clarity and wording of the documentation;
- explaining Cyber Kill Chain and MITRE ATT&CK concepts;
- assisting with the mapping of observed attack behavior to MITRE ATT&CK techniques;
- reviewing the final documentation for consistency.

The case study, sources, attack analysis, and final content were reviewed by the team. AI was used to support the research and documentation process rather than as a primary source of threat intelligence.
